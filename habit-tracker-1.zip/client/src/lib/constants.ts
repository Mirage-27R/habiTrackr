import { Categories } from "@shared/schema";

// App constants
export const APP_NAME = "Habit Tracker";
export const DEFAULT_USER_NAME = "Alex Taylor";

// Preset habit icons mapped to categories
export const CATEGORY_ICONS: Record<string, string> = {
  Sport: "directions_run",
  Health: "water_drop",
  Wellness: "self_improvement",
  Personal: "menu_book",
  Work: "work",
  Education: "school"
};

// For quick access to category list
export const HABIT_CATEGORIES = Categories;

// Demo user data
export const DEMO_USER = {
  name: "Alex Taylor",
  email: "alex@example.com",
  avatar: null // Will be generated from initials
};

// App routes
export const ROUTES = {
  HOME: "/",
  CALENDAR: "/calendar",
  HABITS: "/habits",
  PROGRESS: "/progress",
  JOURNAL: "/journal"
};

// Local storage keys
export const STORAGE_KEYS = {
  USER_SETTINGS: "habit-tracker-settings",
  NOTIFICATION_PERMISSION: "notification-permission-status",
  LAST_ACTIVE_TAB: "last-active-tab",
  WIDGET_SETTINGS: "widget-settings"
};

// Default habit reminder times
export const DEFAULT_REMINDER_TIMES = ["08:00", "12:00", "18:00"];

// Theme options
export const THEMES = {
  PINK: {
    name: "Pink",
    PRIMARY: "hsl(340, 82%, 52%)",  // Pink
    SECONDARY: "hsl(291, 85%, 42%)", // Purple
    PRIMARY_RGB: "220, 40, 106",
    SECONDARY_RGB: "145, 20, 155"
  },
  BLUE: {
    name: "Blue",
    PRIMARY: "hsl(210, 100%, 50%)",  // Blue
    SECONDARY: "hsl(220, 85%, 42%)", // Dark Blue
    PRIMARY_RGB: "0, 128, 255",
    SECONDARY_RGB: "23, 64, 139"
  },
  ORANGE: {
    name: "Orange",
    PRIMARY: "hsl(30, 100%, 50%)",  // Orange
    SECONDARY: "hsl(25, 85%, 42%)", // Dark Orange
    PRIMARY_RGB: "255, 128, 0",
    SECONDARY_RGB: "184, 84, 28"
  },
  GREEN: {
    name: "Green",
    PRIMARY: "hsl(142, 76%, 46%)",  // Green
    SECONDARY: "hsl(160, 85%, 30%)", // Dark Green
    PRIMARY_RGB: "41, 204, 106",
    SECONDARY_RGB: "0, 143, 89"
  },
  PURPLE: {
    name: "Purple",
    PRIMARY: "hsl(270, 76%, 56%)",  // Purple
    SECONDARY: "hsl(280, 85%, 42%)", // Dark Purple
    PRIMARY_RGB: "138, 43, 226",
    SECONDARY_RGB: "107, 13, 143"
  },
  YELLOW: {
    name: "Yellow",
    PRIMARY: "hsl(55, 100%, 50%)",  // Yellow
    SECONDARY: "hsl(45, 85%, 42%)", // Dark Yellow
    PRIMARY_RGB: "255, 236, 0",
    SECONDARY_RGB: "214, 163, 28"
  }
};

// Default theme colors (Pink)
export const COLORS = {
  PRIMARY: THEMES.PINK.PRIMARY,
  SECONDARY: THEMES.PINK.SECONDARY,
  DARK: "hsl(0, 0%, 7%)",
  DARK_CARD: "hsl(0, 0%, 12%)",
  DARK_LIGHTER: "hsl(0, 0%, 16%)",
  SUCCESS: "hsl(122, 39%, 49%)",
  WARNING: "hsl(45, 100%, 51%)",
};
