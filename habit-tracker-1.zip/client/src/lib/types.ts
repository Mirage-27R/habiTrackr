import { Habit, HabitWithCompletion, HabitCompletion, HabitStats } from "@shared/schema";

// Export types from schema for frontend usage
export type { Habit, HabitWithCompletion, HabitCompletion, HabitStats };

// Additional frontend-specific types
export type Tab = "home" | "calendar" | "habits" | "progress" | "journal";

export type NotificationPermissionStatus = "default" | "granted" | "denied";

export interface NotificationOptions {
  title: string;
  body: string;
  icon?: string;
  tag?: string;
  requireInteraction?: boolean;
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
  habitId?: number;
}
