import { NotificationPermissionStatus, NotificationOptions } from "@/lib/types";

/**
 * Request notification permission from the browser
 */
export const requestNotificationPermission = async (): Promise<NotificationPermissionStatus> => {
  if (!("Notification" in window)) {
    return "denied";
  }

  try {
    return await Notification.requestPermission();
  } catch (error) {
    console.error("Error requesting notification permission:", error);
    return "denied";
  }
};

/**
 * Get the current notification permission status
 */
export const getNotificationPermission = (): NotificationPermissionStatus => {
  if (!("Notification" in window)) {
    return "denied";
  }
  return Notification.permission as NotificationPermissionStatus;
};

/**
 * Show a notification with the provided options
 */
export const showNotification = (options: NotificationOptions): Notification | null => {
  if (!("Notification" in window) || Notification.permission !== "granted") {
    return null;
  }

  const notification = new Notification(options.title, {
    body: options.body,
    icon: options.icon,
    tag: options.tag,
    requireInteraction: options.requireInteraction,
  });

  // Add click handler to open the app when notification is clicked
  notification.onclick = () => {
    window.focus();
    notification.close();
  };

  return notification;
};

/**
 * Schedule a notification to show after a specified delay
 */
export const scheduleNotification = (
  options: NotificationOptions, 
  delayInSeconds: number
): number => {
  return window.setTimeout(() => {
    showNotification(options);
  }, delayInSeconds * 1000);
};

/**
 * Cancel a scheduled notification
 */
export const cancelScheduledNotification = (timerId: number): void => {
  window.clearTimeout(timerId);
};

/**
 * Show a motivational notification
 */
export const showMotivationalNotification = (): Notification | null => {
  const motivationalMessages = [
    "Time to build your habits! Keep going strong!",
    "Remember, consistency is key to forming habits!",
    "You're doing great with your habit tracking!",
    "Don't break the streak - check your habits now!",
    "A small daily habit leads to big results over time!"
  ];
  
  // Pick a random motivational message
  const randomIndex = Math.floor(Math.random() * motivationalMessages.length);
  
  return showNotification({
    title: "Habit Tracker",
    body: motivationalMessages[randomIndex],
    icon: "/favicon.ico",
    requireInteraction: true
  });
};

/**
 * Initialize notifications when the app starts
 */
export const initializeNotifications = async (): Promise<void> => {
  if (!("Notification" in window)) {
    console.warn("This browser does not support notifications");
    return;
  }

  // Request permission if not already granted
  if (Notification.permission === "default") {
    await requestNotificationPermission();
  }
  
  // If permission is granted, set up daily reminders
  if (Notification.permission === "granted") {
    setupDailyNotifications();
  }
};

/**
 * Set up daily notification schedules
 */
export const setupDailyNotifications = (): void => {
  const now = new Date();
  
  // Schedule morning reminder if it's before 9am
  if (now.getHours() < 9) {
    const morningTime = new Date();
    morningTime.setHours(9, 0, 0, 0);
    const morningDelay = Math.round((morningTime.getTime() - now.getTime()) / 1000);
    
    scheduleNotification({
      title: "Good Morning!",
      body: "Time to check your habits for the day ahead!",
      icon: "/favicon.ico"
    }, morningDelay);
  }
  
  // Schedule evening reminder if it's before 8pm
  if (now.getHours() < 20) {
    const eveningTime = new Date();
    eveningTime.setHours(20, 0, 0, 0);
    const eveningDelay = Math.round((eveningTime.getTime() - now.getTime()) / 1000);
    
    scheduleNotification({
      title: "Evening Check",
      body: "Have you completed all your habits for today?",
      icon: "/favicon.ico"
    }, eveningDelay);
  }
};

/**
 * Schedule habit reminders based on habit data and reminder times
 */
export const scheduleHabitReminders = (
  habitId: number,
  habitName: string,
  reminderTimes: string[]
): number[] => {
  const now = new Date();
  const scheduledTimers: number[] = [];

  // Process each reminder time
  reminderTimes.forEach(timeStr => {
    try {
      const [hours, minutes] = timeStr.split(':').map(Number);
      
      // Create a date object for the reminder time today
      const reminderTime = new Date();
      reminderTime.setHours(hours, minutes, 0, 0);
      
      // If the time has already passed today, don't schedule
      if (reminderTime <= now) {
        return;
      }
      
      // Calculate delay in seconds
      const delayInSeconds = Math.round((reminderTime.getTime() - now.getTime()) / 1000);
      
      // Schedule the notification
      const timerId = scheduleNotification(
        {
          title: `Time for your habit: ${habitName}`,
          body: `Don't forget to complete this habit today!`,
          icon: '/favicon.ico',
          tag: `habit-${habitId}`,
          requireInteraction: true,
        },
        delayInSeconds
      );
      
      scheduledTimers.push(timerId);
    } catch (error) {
      console.error(`Error scheduling reminder for ${timeStr}:`, error);
    }
  });

  return scheduledTimers;
};