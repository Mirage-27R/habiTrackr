import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { format } from "date-fns";
import { DaysOfWeek } from "@shared/schema";

// Utility for combining class names with Tailwind CSS
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Format a date with a specific format
export function formatDate(date: Date, formatStr: string = "EEEE, MMMM d") {
  return format(date, formatStr);
}

// Get current day of week as string
export function getCurrentDayOfWeek(): string {
  return format(new Date(), "EEEE");
}

// Get shortened day name (e.g., "M" for Monday)
export function getShortDayName(day: string): string {
  return day.charAt(0);
}

// Check if a day is in the repeat days array
export function isDayInRepeatDays(day: string, repeatDays: string[]): boolean {
  return repeatDays.includes(day);
}

// Calculate completion percentage
export function calculateCompletionPercentage(completed: number, total: number): number {
  if (total === 0) return 0;
  return Math.round((completed / total) * 100);
}

// Helper to map day index to day name
export function getDayNameFromIndex(index: number): string {
  return DaysOfWeek[index];
}

// Helper to get all days in short format for UI
export function getShortDays(): string[] {
  return DaysOfWeek.map(day => day.charAt(0));
}

// Convert time string (HH:MM) to a more readable format
export function formatTimeString(time: string): string {
  const [hours, minutes] = time.split(':');
  const hour = parseInt(hours, 10);
  const period = hour >= 12 ? 'PM' : 'AM';
  const formattedHour = hour % 12 || 12;
  return `${formattedHour}:${minutes} ${period}`;
}

// Generate a random avatar based on initials
export function generateDefaultAvatarUrl(name: string): string {
  // Get initials from name
  const initials = name
    .split(' ')
    .map(n => n[0])
    .join('')
    .toUpperCase();
  
  // Generate a deterministic background color based on name
  const colors = [
    '5E35B1', 'D81B60', '1E88E5', '43A047', 
    'E53935', '8E24AA', '3949AB', '039BE5'
  ];
  
  // Simple hash function for name to select color
  const hash = name.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  const colorIndex = hash % colors.length;
  const bgColor = colors[colorIndex];
  
  // Return an SVG data URL
  return `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Crect width='100' height='100' fill='%23${bgColor}'/%3E%3Ctext x='50' y='50' font-family='Arial' font-size='40' font-weight='bold' fill='white' text-anchor='middle' dominant-baseline='middle'%3E${initials}%3C/text%3E%3C/svg%3E`;
}

export function generateAvatarUrl(name: string): string {
  const savedSettings = localStorage.getItem('widget-settings');
  if (savedSettings) {
    const settings = JSON.parse(savedSettings);
    if (settings.profilePicture) {
      return settings.profilePicture;
    }
  }
  return generateDefaultAvatarUrl(name);
}
