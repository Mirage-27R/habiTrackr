import React from "react";
import AppHeader from "@/components/AppHeader";
import TabNavigation from "@/components/TabNavigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { formatDate } from "@/lib/utils";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

// Placeholder for the journal page - would be integrated with backend in a complete app
export default function Journal() {
  const { toast } = useToast();
  const today = new Date();
  const [entry, setEntry] = React.useState("");
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (entry.trim()) {
      // Would save to backend in a complete implementation
      toast({
        title: "Journal entry saved",
        description: "Your reflection has been recorded.",
      });
    } else {
      toast({
        title: "Cannot save empty entry",
        description: "Please write something before saving.",
        variant: "destructive",
      });
    }
  };
  
  return (
    <div className="min-h-screen bg-dark text-white pb-20">
      <TabNavigation activeTab="journal" />
      
      <div className="p-4">
        <h2 className="text-xl font-semibold mb-4">Habit Journal</h2>
        
        <Card className="bg-dark-card text-white border-dark-lighter mb-6">
          <CardHeader>
            <CardTitle>Today's Reflection - {formatDate(today)}</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit}>
              <div className="mb-4">
                <p className="text-sm text-gray-400 mb-2">
                  Reflect on today's habits. What went well? What could improve?
                </p>
                <Textarea
                  className="w-full bg-dark-lighter border-none rounded-lg p-3 text-white focus:ring-2 focus:ring-primary/50 outline-none resize-y min-h-[150px]"
                  placeholder="Write your thoughts here..."
                  value={entry}
                  onChange={(e) => setEntry(e.target.value)}
                />
              </div>
              
              <div className="flex justify-end">
                <Button
                  type="submit"
                  className="bg-primary hover:bg-primary/90 text-white"
                >
                  Save Entry
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
        
        <Card className="bg-dark-card text-white border-dark-lighter">
          <CardHeader>
            <CardTitle>Previous Entries</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-400 text-center py-8">
              You haven't created any previous journal entries yet.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
