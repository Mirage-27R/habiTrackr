import React, { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { formatDate } from "@/lib/utils";
import { HabitWithCompletion, HabitStats } from "@shared/schema";
import { STORAGE_KEYS } from "@/lib/constants";
import AppHeader from "@/components/AppHeader";
import DateHeader from "@/components/DateHeader";
import HabitList from "@/components/HabitList";
import ProgressStats from "@/components/ProgressStats";
import PresetHabits from "@/components/PresetHabits";
import FloatingActionButton from "@/components/FloatingActionButton";
import AddHabitModal from "@/components/AddHabitModal";
import { useToast } from "@/hooks/use-toast";
import { ChevronUp } from "lucide-react";

// Updated widget settings interface to include userName
interface WidgetSettings {
  userName: string; // Added userName field
  showPresetHabits: boolean;
  showProgressStats: boolean;
  darkMode: boolean;
  theme: string;
  enableNotifications: boolean;
}

// Default settings with placeholder userName
const defaultSettings: WidgetSettings = {
  userName: "Alex Taylor", // Added placeholder userName
  showPresetHabits: true,
  showProgressStats: true,
  darkMode: true,
  theme: "PINK",
  enableNotifications: true,
};

export default function Home() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [widgetSettings, setWidgetSettings] = useState<WidgetSettings>(defaultSettings);
  const [showMoreContent, setShowMoreContent] = useState(false);
  const { toast } = useToast();

  // Load widget settings from localStorage
  useEffect(() => {
    try {
      const savedSettings = localStorage.getItem(STORAGE_KEYS.WIDGET_SETTINGS);
      if (savedSettings) {
        setWidgetSettings(JSON.parse(savedSettings));
      }
    } catch (error) {
      console.error("Error loading widget settings:", error);
    }
  }, []);

  // Fetch today's habits with completion status
  const { 
    data: habits, 
    isLoading: isLoadingHabits,
    error: habitsError 
  } = useQuery<HabitWithCompletion[]>({
    queryKey: ['/api/habits/with-completion/today'],
  });

  // Fetch stats data
  const { 
    data: stats, 
    isLoading: isLoadingStats 
  } = useQuery<HabitStats>({
    queryKey: ['/api/stats'],
  });

  // Handle marking a habit as complete/incomplete
  const toggleHabit = useMutation({
    mutationFn: async ({ id, completed }: { id: number, completed: boolean }) => {
      const response = await fetch(`/api/habits/${id}/complete`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ completed }),
      });

      if (!response.ok) {
        throw new Error('Failed to update habit completion status');
      }

      return response.json();
    },
    onSuccess: () => {
      // Invalidate queries to refresh the data
      queryClient.invalidateQueries({ queryKey: ['/api/habits/with-completion/today'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });

      // Show notification on habit completion if enabled
      if (widgetSettings.enableNotifications && Notification.permission === 'granted') {
        const completedHabits = habits?.filter(h => h.isCompletedToday)?.length || 0;
        const totalHabits = habits?.length || 0;

        if (completedHabits > 0 && completedHabits === totalHabits) {
          // Send a notification when all habits are completed
          new Notification("All Habits Completed!", {
            body: "Great job! You've completed all your habits for today.",
            icon: "/favicon.ico"
          });
        }
      }
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update habit completion status",
        variant: "destructive",
      });
      console.error("Error toggling habit completion:", error);
    }
  });

  const handleToggleHabit = (id: number, completed: boolean) => {
    toggleHabit.mutate({ id, completed });
  };

  // Handle swipe and touch events
  useEffect(() => {
    let touchStartY = 0;
    const minSwipeDistance = 50;

    const handleTouchStart = (e: TouchEvent) => {
      touchStartY = e.touches[0].clientY;
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (!touchStartY) return;

      const touchEndY = e.touches[0].clientY;
      const distance = touchStartY - touchEndY;

      // If swiped up with enough distance
      if (distance > minSwipeDistance) {
        setShowMoreContent(true);
        touchStartY = 0;
      }
      // If swiped down with enough distance
      else if (distance < -minSwipeDistance) {
        setShowMoreContent(false);
        touchStartY = 0;
      }
    };

    const handleSwipeIndicatorClick = () => {
      setShowMoreContent(!showMoreContent);
    };

    // Add event listeners
    document.addEventListener('touchstart', handleTouchStart);
    document.addEventListener('touchmove', handleTouchMove);

    // Add click listener to the swipe indicator
    const swipeIndicator = document.getElementById('swipe-indicator');
    if (swipeIndicator) {
      swipeIndicator.addEventListener('click', handleSwipeIndicatorClick);
    }

    return () => {
      // Clean up
      document.removeEventListener('touchstart', handleTouchStart);
      document.removeEventListener('touchmove', handleTouchMove);
      if (swipeIndicator) {
        swipeIndicator.removeEventListener('click', handleSwipeIndicatorClick);
      }
    };
  }, [showMoreContent]);

  return (
    <div className="min-h-screen bg-dark text-white pb-20">
      <AppHeader userName={widgetSettings.userName} /> {/* Pass userName prop */}

      {/* Swipe indicator */}
      <div 
        id="swipe-indicator"
        className="flex justify-center mb-1 cursor-pointer"
        onClick={() => setShowMoreContent(!showMoreContent)}
      >
        <div className="bg-dark-lighter rounded-full px-3 py-1 flex items-center gap-1 text-xs text-white/70">
          <ChevronUp 
            className={`w-4 h-4 transition-transform duration-300 ${showMoreContent ? 'rotate-180' : ''}`} 
          />
          <span>{showMoreContent ? 'Swipe down to collapse' : 'Swipe up for more'}</span>
        </div>
      </div>

      <DateHeader date={new Date()} />

      <div className="px-4 py-2">
        <h2 className="text-lg font-medium mb-2">Today's Habits</h2>
        {habitsError ? (
          <div className="p-4 text-center text-destructive">
            Error loading habits. Please try again.
          </div>
        ) : (
          <HabitList 
            habits={habits || []} 
            isLoading={isLoadingHabits} 
            onToggleHabit={handleToggleHabit}
            isPending={toggleHabit.isPending}
            showEmptyMessage={true}
            emptyMessage="You have no habits for today. Add some habits to get started!"
          />
        )}
      </div>

      {/* Additional content that appears when swiped up */}
      <div 
        className={`transition-all duration-500 ease-in-out overflow-hidden ${
          showMoreContent ? 'max-h-[1000px] opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        {/* Stats section - always include in DOM but control visibility */}
        <div className={`mt-4 ${widgetSettings.showProgressStats ? 'block' : 'hidden'}`}>
          <ProgressStats stats={stats} isLoading={isLoadingStats} />
        </div>

        {/* Preset habits section - always include in DOM but control visibility */}
        <div className={`mt-4 ${widgetSettings.showPresetHabits ? 'block' : 'hidden'}`}>
          <PresetHabits />
        </div>

        {/* Additional information when expanded */}
        <div className="px-4 py-4 mt-4">
          <h3 className="text-lg font-medium mb-2 text-primary">Tips & Motivation</h3>
          <div className="bg-dark-card p-4 rounded-lg">
            <p className="text-gray-300 mb-2">
              💡 <strong>Tip of the day:</strong> Break large habits into smaller, more manageable tasks.
            </p>
            <p className="text-gray-300 italic">
              "Success is the sum of small efforts, repeated day in and day out."
            </p>
          </div>
        </div>
      </div>

      <FloatingActionButton onClick={() => setIsModalOpen(true)} />

      <AddHabitModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
      />
    </div>
  );
}