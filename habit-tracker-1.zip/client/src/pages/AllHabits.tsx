import React, { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import AppHeader from "@/components/AppHeader";
import TabNavigation from "@/components/TabNavigation";
import { Habit, HabitWithCompletion } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Pencil, Trash2, Plus, CalendarIcon, ListChecks } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import FloatingActionButton from "@/components/FloatingActionButton";
import AddHabitModal from "@/components/AddHabitModal";
import { Badge } from "@/components/ui/badge";
import { Categories } from "@shared/schema";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { cn, formatDate, getCurrentDayOfWeek } from "@/lib/utils";
import { format, isSameDay } from "date-fns";
import HabitList from "@/components/HabitList";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";

export default function AllHabits() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [viewMode, setViewMode] = useState<'list' | 'calendar'>('list');
  const { toast } = useToast();
  
  // Fetch all habits
  const { 
    data: habits, 
    isLoading
  } = useQuery<Habit[]>({
    queryKey: ['/api/habits'],
  });
  
  // Delete habit mutation
  const deleteHabit = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/habits/${id}`, {
        method: 'DELETE',
      });
      
      if (!response.ok) {
        throw new Error('Failed to delete habit');
      }
      
      return id;
    },
    onSuccess: () => {
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/habits'] });
      queryClient.invalidateQueries({ queryKey: ['/api/habits/with-completion/today'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
      
      toast({
        title: "Habit deleted",
        description: "The habit has been removed successfully.",
      });
      setDeleteId(null);
    },
    onError: (error) => {
      console.error("Error deleting habit:", error);
      toast({
        title: "Error",
        description: "Failed to delete the habit. Please try again.",
        variant: "destructive",
      });
      setDeleteId(null);
    }
  });
  
  // Group habits by category
  const habitsByCategory = React.useMemo(() => {
    if (!habits) return {};
    
    const grouped: Record<string, Habit[]> = {};
    Categories.forEach(category => {
      grouped[category] = [];
    });
    
    habits.forEach(habit => {
      if (grouped[habit.category]) {
        grouped[habit.category].push(habit);
      } else {
        // Handle any custom categories
        grouped[habit.category] = [habit];
      }
    });
    
    return grouped;
  }, [habits]);
  
  // Active & inactive habits
  const activeHabits = React.useMemo(() => {
    return habits?.filter(h => h.isActive) || [];
  }, [habits]);
  
  const inactiveHabits = React.useMemo(() => {
    return habits?.filter(h => !h.isActive) || [];
  }, [habits]);
  
  // Get the day of week for the selected date
  const selectedDay = selectedDate 
    ? format(selectedDate, 'EEEE') 
    : getCurrentDayOfWeek();
  
  // Fetch habits for the selected day
  const { 
    data: dayHabits, 
    isLoading: isDayHabitsLoading 
  } = useQuery<Habit[]>({
    queryKey: ['/api/habits/day', selectedDay],
    queryFn: async () => {
      const res = await fetch(`/api/habits/day/${selectedDay}`);
      if (!res.ok) throw new Error('Failed to fetch habits');
      return res.json();
    },
  });
  
  // Fetch completion data for today to show completion status if viewing today
  const { data: todayHabits } = useQuery<HabitWithCompletion[]>({
    queryKey: ['/api/habits/with-completion/today'],
    // Only run this query if looking at today
    enabled: selectedDate ? isSameDay(selectedDate, new Date()) : false,
  });
  
  // Handle marking a habit as complete/incomplete
  const toggleHabit = useMutation({
    mutationFn: async ({ id, completed }: { id: number, completed: boolean }) => {
      const response = await fetch(`/api/habits/${id}/complete`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ completed }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to update habit completion status');
      }
      
      return response.json();
    },
    onSuccess: () => {
      // Invalidate queries to refresh the data
      queryClient.invalidateQueries({ queryKey: ['/api/habits/with-completion/today'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update habit completion status",
        variant: "destructive",
      });
    }
  });
  
  // Combine habits with completion status if viewing today
  const habitsWithCompletionStatus = React.useMemo(() => {
    if (!dayHabits) return [];
    
    // If viewing today and we have completion data, merge it
    if (selectedDate && isSameDay(selectedDate, new Date()) && todayHabits) {
      return dayHabits.map(habit => {
        const todayHabit = todayHabits.find(h => h.id === habit.id);
        return {
          ...habit,
          isCompletedToday: todayHabit ? todayHabit.isCompletedToday : false
        };
      });
    }
    
    // Otherwise, return habits without completion status
    return dayHabits.map(habit => ({
      ...habit,
      isCompletedToday: false
    }));
  }, [dayHabits, todayHabits, selectedDate]);
  
  // Handle drag end event for reordering habits
  const handleDragEnd = (result: any) => {
    if (!result.destination) return;
    
    const items = Array.from(activeHabits);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);
    
    // Here you would typically update the order in the database
    // For now, we'll just show a toast notification
    toast({
      title: "Habit reordered",
      description: `${reorderedItem.name} has been moved to position ${result.destination.index + 1}`,
    });
  };
  
  // Format days array for display
  const formatDays = (days: string[]): string => {
    if (days.length === 7) return "Every day";
    if (days.length === 0) return "No days selected";
    
    // Weekdays only (Mon-Fri)
    if (days.length === 5 && 
        days.includes("Monday") && 
        days.includes("Tuesday") && 
        days.includes("Wednesday") && 
        days.includes("Thursday") && 
        days.includes("Friday") && 
        !days.includes("Saturday") && 
        !days.includes("Sunday")) {
      return "Weekdays";
    }
    
    // Weekend only
    if (days.length === 2 && 
        days.includes("Saturday") && 
        days.includes("Sunday")) {
      return "Weekends";
    }
    
    // Otherwise, list the days with shortname
    return days.map(d => d.substring(0, 3)).join(", ");
  };
  
  return (
    <div className="min-h-screen bg-dark text-white pb-20">
      <TabNavigation activeTab="habits" />
      
      <div className="p-4">
        <div className="mb-4 flex justify-between items-center">
          <h2 className="text-xl font-semibold">Habits</h2>
          <div className="flex space-x-2">
            <Button 
              variant="outline" 
              size="sm" 
              className={`${viewMode === 'list' ? 'bg-primary text-white' : 'bg-dark-lighter text-gray-400'}`}
              onClick={() => setViewMode('list')}
            >
              <ListChecks className="w-4 h-4 mr-1" />
              List
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className={`${viewMode === 'calendar' ? 'bg-primary text-white' : 'bg-dark-lighter text-gray-400'}`}
              onClick={() => setViewMode('calendar')}
            >
              <CalendarIcon className="w-4 h-4 mr-1" />
              Calendar
            </Button>
          </div>
        </div>
        
        {viewMode === 'calendar' ? (
          <div className="mb-4">
            <div className="bg-dark-card rounded-lg p-4 mb-6">
              <h2 className="text-lg font-semibold mb-4">Select Date</h2>
              <CalendarComponent
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                className="bg-dark-card rounded-md border-dark-lighter text-white p-2"
              />
            </div>
            
            <h2 className="text-lg font-semibold mt-6 mb-3">
              Habits for {selectedDate ? formatDate(selectedDate) : "Today"}
            </h2>
            
            <HabitList 
              habits={habitsWithCompletionStatus} 
              isLoading={isDayHabitsLoading}
              isPending={toggleHabit.isPending}
              onToggleHabit={(id, completed) => {
                // Only allow toggling if viewing today
                if (selectedDate && isSameDay(selectedDate, new Date())) {
                  toggleHabit.mutate({ id, completed });
                } else {
                  toast({
                    title: "Cannot complete",
                    description: "You can only mark habits as complete for today",
                    variant: "destructive",
                  });
                }
              }}
              showEmptyMessage={!isDayHabitsLoading && (!dayHabits || dayHabits.length === 0)}
              emptyMessage={`No habits scheduled for ${selectedDay}`}
            />
          </div>
        ) : (
          <Tabs defaultValue="active" className="w-full">
            <TabsList className="w-full bg-dark-lighter mb-4">
              <TabsTrigger 
                value="active" 
                className="flex-1 data-[state=active]:bg-primary data-[state=active]:text-white"
              >
                Active
              </TabsTrigger>
              <TabsTrigger 
                value="inactive" 
                className="flex-1 data-[state=active]:bg-primary data-[state=active]:text-white"
              >
                Inactive
              </TabsTrigger>
              <TabsTrigger 
                value="categories" 
                className="flex-1 data-[state=active]:bg-primary data-[state=active]:text-white"
              >
                Categories
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="active">
              {isLoading ? (
                <div className="text-center py-8">Loading habits...</div>
              ) : activeHabits.length === 0 ? (
                <div className="text-center py-8 text-gray-400">
                  <p>You haven't created any active habits yet.</p>
                  <Button 
                    className="mt-4 bg-primary hover:bg-primary/90"
                    onClick={() => setIsModalOpen(true)}
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Add Your First Habit
                  </Button>
                </div>
              ) : (
                <DragDropContext onDragEnd={handleDragEnd}>
                  <Droppable droppableId="habit-list">
                    {(provided) => (
                      <div 
                        className="space-y-3" 
                        {...provided.droppableProps}
                        ref={provided.innerRef}
                      >
                        {activeHabits.map((habit, index) => (
                          <Draggable key={habit.id} draggableId={`habit-${habit.id}`} index={index}>
                            {(provided) => (
                              <div
                                ref={provided.innerRef}
                                {...provided.draggableProps}
                                {...provided.dragHandleProps}
                              >
                                <Card className="bg-dark-card border-dark-lighter">
                                  <CardContent className="p-4">
                                    <div className="flex justify-between items-start">
                                      <div>
                                        <h3 className="text-primary text-lg font-medium">{habit.name}</h3>
                                        <p className="text-gray-400 text-sm mt-1">{habit.description}</p>
                                        <div className="flex gap-2 mt-2">
                                          <Badge variant="outline" className="bg-primary/20 text-primary border-none">
                                            {habit.category}
                                          </Badge>
                                          <Badge variant="outline" className="bg-dark-lighter text-gray-400 border-none">
                                            {formatDays(habit.repeatDays)}
                                          </Badge>
                                        </div>
                                      </div>
                                      <div className="flex space-x-1">
                                        <Button size="icon" variant="ghost" className="h-8 w-8 text-gray-400">
                                          <Pencil className="h-4 w-4" />
                                        </Button>
                                        <Button 
                                          size="icon" 
                                          variant="ghost" 
                                          className="h-8 w-8 text-destructive"
                                          onClick={() => setDeleteId(habit.id)}
                                        >
                                          <Trash2 className="h-4 w-4" />
                                        </Button>
                                      </div>
                                    </div>
                                  </CardContent>
                                </Card>
                              </div>
                            )}
                          </Draggable>
                        ))}
                        {provided.placeholder}
                      </div>
                    )}
                  </Droppable>
                </DragDropContext>
              )}
            </TabsContent>
            
            <TabsContent value="inactive">
              {isLoading ? (
                <div className="text-center py-8">Loading habits...</div>
              ) : inactiveHabits.length === 0 ? (
                <div className="text-center py-8 text-gray-400">
                  <p>No inactive habits found.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {inactiveHabits.map(habit => (
                    <Card key={habit.id} className="bg-dark-card border-dark-lighter opacity-60">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="text-gray-400 text-lg font-medium">{habit.name}</h3>
                            <p className="text-gray-500 text-sm mt-1">{habit.description}</p>
                            <div className="flex gap-2 mt-2">
                              <Badge variant="outline" className="bg-dark-lighter text-gray-400 border-none">
                                {habit.category}
                              </Badge>
                            </div>
                          </div>
                          <div className="flex space-x-1">
                            <Button size="icon" variant="ghost" className="h-8 w-8 text-gray-500">
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button 
                              size="icon" 
                              variant="ghost" 
                              className="h-8 w-8 text-gray-500"
                              onClick={() => setDeleteId(habit.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="categories">
              {isLoading ? (
                <div className="text-center py-8">Loading categories...</div>
              ) : (
                <div className="space-y-6">
                  {Object.entries(habitsByCategory).map(([category, categoryHabits]) => (
                    categoryHabits.length > 0 && (
                      <Card key={category} className="bg-dark-card border-dark-lighter">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-lg text-primary">
                            {category}
                            <Badge className="ml-2 bg-primary/20 text-primary border-none">
                              {categoryHabits.length}
                            </Badge>
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            {categoryHabits.map(habit => (
                              <div key={habit.id} className="p-3 bg-dark-lighter rounded-md flex justify-between items-center">
                                <span className="font-medium">{habit.name}</span>
                                <Badge variant={habit.isActive ? "default" : "outline"} className={habit.isActive ? "bg-green-500" : "text-gray-400"}>
                                  {habit.isActive ? "Active" : "Inactive"}
                                </Badge>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    )
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        )}
      </div>
      
      <FloatingActionButton onClick={() => setIsModalOpen(true)} />
      
      <AddHabitModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
      />
      
      <AlertDialog open={deleteId !== null} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent className="bg-dark-card text-white border-dark-lighter">
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription className="text-gray-400">
              This will permanently delete this habit and all its completion records.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-dark-lighter text-white hover:bg-dark-lighter/90 hover:text-white">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction 
              className="bg-destructive text-white hover:bg-destructive/90"
              onClick={() => {
                if (deleteId !== null) {
                  deleteHabit.mutate(deleteId);
                }
              }}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}