import React, { useState } from "react";
import AppHeader from "@/components/AppHeader";
import TabNavigation from "@/components/TabNavigation";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { useQuery } from "@tanstack/react-query";
import { Habit, HabitWithCompletion } from "@shared/schema";
import { cn, formatDate, getCurrentDayOfWeek } from "@/lib/utils";
import { format, isSameDay } from "date-fns";
import HabitList from "@/components/HabitList";
import { useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Calendar() {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const { toast } = useToast();
  
  // Get the day of week for the selected date
  const selectedDay = selectedDate 
    ? format(selectedDate, 'EEEE') 
    : getCurrentDayOfWeek();
  
  // Fetch habits for the selected day
  const { 
    data: habits, 
    isLoading 
  } = useQuery<Habit[]>({
    queryKey: ['/api/habits/day', selectedDay],
    queryFn: async () => {
      const res = await fetch(`/api/habits/day/${selectedDay}`);
      if (!res.ok) throw new Error('Failed to fetch habits');
      return res.json();
    },
  });
  
  // Fetch completion data for today to show completion status if viewing today
  const { data: todayHabits } = useQuery<HabitWithCompletion[]>({
    queryKey: ['/api/habits/with-completion/today'],
    // Only run this query if looking at today
    enabled: selectedDate ? isSameDay(selectedDate, new Date()) : false,
  });
  
  // Handle marking a habit as complete/incomplete
  const toggleHabit = useMutation({
    mutationFn: async ({ id, completed }: { id: number, completed: boolean }) => {
      const response = await fetch(`/api/habits/${id}/complete`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ completed }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to update habit completion status');
      }
      
      return response.json();
    },
    onSuccess: () => {
      // Invalidate queries to refresh the data
      queryClient.invalidateQueries({ queryKey: ['/api/habits/with-completion/today'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update habit completion status",
        variant: "destructive",
      });
    }
  });
  
  // Combine habits with completion status if viewing today
  const habitsWithCompletionStatus = React.useMemo(() => {
    if (!habits) return [];
    
    // If viewing today and we have completion data, merge it
    if (selectedDate && isSameDay(selectedDate, new Date()) && todayHabits) {
      return habits.map(habit => {
        const todayHabit = todayHabits.find(h => h.id === habit.id);
        return {
          ...habit,
          isCompletedToday: todayHabit ? todayHabit.isCompletedToday : false
        };
      });
    }
    
    // Otherwise, return habits without completion status
    return habits.map(habit => ({
      ...habit,
      isCompletedToday: false
    }));
  }, [habits, todayHabits, selectedDate]);
  
  return (
    <div className="min-h-screen bg-dark text-white pb-20">
      <AppHeader userName="Alex Taylor" />
      <TabNavigation activeTab="calendar" />
      
      <div className="p-4">
        <div className="bg-dark-card rounded-lg p-4 mb-6">
          <h2 className="text-lg font-semibold mb-4">Select Date</h2>
          <CalendarComponent
            mode="single"
            selected={selectedDate}
            onSelect={setSelectedDate}
            className="bg-dark-card rounded-md border-dark-lighter text-white p-2"
          />
        </div>
        
        <h2 className="text-lg font-semibold mt-6 mb-3">
          Habits for {selectedDate ? formatDate(selectedDate) : "Today"}
        </h2>
        
        <HabitList 
          habits={habitsWithCompletionStatus} 
          isLoading={isLoading}
          isPending={toggleHabit.isPending}
          onToggleHabit={(id, completed) => {
            // Only allow toggling if viewing today
            if (selectedDate && isSameDay(selectedDate, new Date())) {
              toggleHabit.mutate({ id, completed });
            } else {
              toast({
                title: "Cannot complete",
                description: "You can only mark habits as complete for today",
                variant: "destructive",
              });
            }
          }}
          showEmptyMessage={!isLoading && (!habits || habits.length === 0)}
          emptyMessage={`No habits scheduled for ${selectedDay}`}
        />
      </div>
    </div>
  );
}
