import React, { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import AppHeader from "@/components/AppHeader";
import TabNavigation from "@/components/TabNavigation";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bell } from "lucide-react";
import { STORAGE_KEYS, THEMES } from "@/lib/constants";
import { generateDefaultAvatarUrl } from '@/lib/utils';

// Define the widget settings interface
interface WidgetSettings {
  showPresetHabits: boolean;
  showProgressStats: boolean;
  darkMode: boolean;
  theme: string;
  enableNotifications: boolean;
  userName: string;
  profilePicture: string;
}

// Default settings
const defaultSettings: WidgetSettings = {
  showPresetHabits: true,
  showProgressStats: true,
  darkMode: true,
  theme: "PINK",
  enableNotifications: true,
  userName: '',
  profilePicture: generateDefaultAvatarUrl('User')
};

export default function Settings() {
  const { toast } = useToast();
  const [settings, setSettings] = useState<WidgetSettings>(defaultSettings);

  // Load settings from local storage on component mount
  useEffect(() => {
    const savedSettings = localStorage.getItem(STORAGE_KEYS.WIDGET_SETTINGS);
    if (savedSettings) {
      try {
        const parsed = JSON.parse(savedSettings);
        setSettings({
          ...defaultSettings,
          ...parsed
        });
      } catch (error) {
        console.error("Error parsing settings:", error);
      }
    }
  }, []);

  // Save settings to local storage whenever they change
  const saveSettings = (newSettings: WidgetSettings) => {
    localStorage.setItem(STORAGE_KEYS.WIDGET_SETTINGS, JSON.stringify(newSettings));
    setSettings(newSettings);

    // If this is a theme change, apply it immediately
    if (newSettings.theme !== settings.theme) {
      const theme = THEMES[newSettings.theme as keyof typeof THEMES];

      // Apply theme change logic
      document.documentElement.style.setProperty('--color-primary', theme.PRIMARY);
      document.documentElement.style.setProperty('--color-secondary', theme.SECONDARY);
      document.documentElement.style.setProperty('--color-primary-rgb', theme.PRIMARY_RGB);
      document.documentElement.style.setProperty('--color-secondary-rgb', theme.SECONDARY_RGB);
    }

    toast({
      title: "Settings Saved",
      description: "Your preferences have been updated",
    });
  };

  // Handle toggle for boolean settings
  const handleToggle = (setting: keyof Omit<WidgetSettings, 'userName' | 'profilePicture' | 'theme'>) => {
    const newSettings = { ...settings, [setting]: !settings[setting] };
    saveSettings(newSettings);
  };

  // Handle theme change
  const handleThemeChange = (theme: string) => {
    const newSettings = { ...settings, theme };
    saveSettings(newSettings);
  };

  const handleSettingsChange = (changes: Partial<Pick<WidgetSettings, 'userName' | 'profilePicture'>>) => {
    const newSettings = { ...settings, ...changes };
    saveSettings(newSettings);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        handleSettingsChange({ profilePicture: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  // Request notification permission
  const requestNotificationPermission = async () => {
    if (!("Notification" in window)) {
      toast({
        title: "Notifications Not Supported",
        description: "Your browser does not support notifications",
        variant: "destructive",
      });
      return;
    }

    try {
      const permission = await Notification.requestPermission();
      if (permission === "granted") {
        const newSettings = { ...settings, enableNotifications: true };
        saveSettings(newSettings);

        // Show a test notification
        new Notification("Habit Tracker", {
          body: "Notifications are now enabled!",
          icon: "/favicon.ico"
        });
      } else {
        toast({
          title: "Permission Denied",
          description: "You need to allow notifications in your browser settings",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error requesting notification permission:", error);
      toast({
        title: "Error",
        description: "Failed to request notification permission",
        variant: "destructive",
      });
    }
  };

  // Reset to default settings
  const handleReset = () => {
    saveSettings(defaultSettings);
  };

  // Get the current theme object
  const currentTheme = THEMES[settings.theme as keyof typeof THEMES] || THEMES.PINK;

  return (
    <div className="min-h-screen bg-dark text-white pb-20">
      <AppHeader userName={settings.userName} profilePicture={settings.profilePicture}/>

      <div className="p-4">
        <h2 className="text-xl font-semibold mb-4">Settings</h2>

        <Card className="bg-dark-card text-white border-dark-lighter mb-4">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Home Screen Widgets</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="preset-habits">Preset Habits</Label>
                  <p className="text-sm text-gray-400">Show preset habits on home screen</p>
                </div>
                <Switch
                  id="preset-habits"
                  checked={settings.showPresetHabits}
                  onCheckedChange={() => handleToggle('showPresetHabits')}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="progress-stats">Progress Stats</Label>
                  <p className="text-sm text-gray-400">Show progress statistics on home screen</p>
                </div>
                <Switch
                  id="progress-stats"
                  checked={settings.showProgressStats}
                  onCheckedChange={() => handleToggle('showProgressStats')}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-dark-card text-white border-dark-lighter mb-4">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Theme</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <p className="text-sm text-gray-400 mb-2">Choose your preferred accent color</p>

              <div className="grid grid-cols-3 gap-3">
                {Object.entries(THEMES).map(([key, theme]) => (
                  <button
                    key={key}
                    onClick={() => handleThemeChange(key)}
                    className={`p-3 rounded-lg flex flex-col items-center justify-center transition-transform ${
                      settings.theme === key ? 'ring-2 scale-105' : ''
                    }`}
                    style={{
                      backgroundColor: 'hsl(0, 0%, 12%)',
                      borderColor: theme.PRIMARY,
                      boxShadow: settings.theme === key ? `0 0 0 2px ${theme.PRIMARY}` : 'none'
                    }}
                  >
                    <div
                      className="w-8 h-8 rounded-full mb-2"
                      style={{ backgroundColor: theme.PRIMARY }}
                    />
                    <span className="text-xs font-medium">{theme.name}</span>
                  </button>
                ))}
              </div>

              <div className="flex items-center justify-between mt-4">
                <div className="space-y-0.5">
                  <Label htmlFor="dark-mode">Dark Mode</Label>
                  <p className="text-sm text-gray-400">Use dark theme throughout the app</p>
                </div>
                <Switch
                  id="dark-mode"
                  checked={settings.darkMode}
                  onCheckedChange={() => handleToggle('darkMode')}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-dark-card text-white border-dark-lighter mb-4">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Notifications</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="enable-notifications">Enable Notifications</Label>
                  <p className="text-sm text-gray-400">Get reminders for your habits</p>
                </div>
                <Switch
                  id="enable-notifications"
                  checked={settings.enableNotifications}
                  onCheckedChange={() => handleToggle('enableNotifications')}
                />
              </div>

              <Button
                variant="outline"
                className="w-full flex items-center justify-center gap-2"
                onClick={requestNotificationPermission}
              >
                <Bell className="h-4 w-4" />
                <span>Request Permission</span>
              </Button>

              <p className="text-xs text-gray-400">
                Note: You need to grant notification permission in your browser for reminders to work
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-dark-card text-white border-dark-lighter">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Reset Preferences</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-400 mb-4">
              Reset all settings to their default values
            </p>
            <Button
              variant="destructive"
              onClick={handleReset}
            >
              Reset to Defaults
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-dark-card text-white border-dark-lighter mb-4">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Profile Settings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex flex-col gap-2">
                <Label htmlFor="userName">Display Name</Label>
                <input
                  id="userName"
                  type="text"
                  value={settings.userName}
                  onChange={(e) => handleSettingsChange({ userName: e.target.value })}
                  className="bg-dark-lighter text-white p-2 rounded-md"
                />
              </div>
              <div className="flex flex-col gap-2">
                <Label htmlFor="profilePicture">Profile Picture</Label>
                <div className="flex items-center gap-4">
                  <img
                    src={settings.profilePicture}
                    alt="Profile"
                    className="w-16 h-16 rounded-full object-cover"
                  />
                  <input
                    id="profilePicture"
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="bg-dark-lighter text-white p-2 rounded-md"
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}