import React from "react";
import AppHeader from "@/components/AppHeader";
import TabNavigation from "@/components/TabNavigation";
import { useQuery } from "@tanstack/react-query";
import { HabitStats } from "@shared/schema";
import { Progress as ProgressBar } from "@/components/ui/progress";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Flame, TrendingUp, Star, Calendar } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { format, subDays } from "date-fns";

// Sample data for charts - in a real app this would come from the API
const last7DaysData = Array.from({ length: 7 }, (_, i) => {
  const date = subDays(new Date(), i);
  return {
    day: format(date, 'EEE'),
    completed: Math.floor(Math.random() * 5) + 1,
  };
}).reverse();

const monthlyData = Array.from({ length: 30 }, (_, i) => {
  const date = subDays(new Date(), i);
  return {
    date: format(date, 'dd MMM'),
    completed: Math.floor(Math.random() * 5) + 1,
  };
}).reverse();

export default function Progress() {
  // Fetch stats data
  const { 
    data: stats, 
    isLoading: isLoadingStats 
  } = useQuery<HabitStats>({
    queryKey: ['/api/stats'],
  });
  
  return (
    <div className="min-h-screen bg-dark text-white pb-20">
      <TabNavigation activeTab="progress" />
      
      <div className="p-4">
        <h2 className="text-xl font-semibold mb-4">Your Progress</h2>
        
        <Card className="bg-dark-card text-white border-dark-lighter mb-6">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Overall Completion</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoadingStats ? (
              <Skeleton className="h-4 w-full bg-dark-lighter" />
            ) : (
              <>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-gray-400">Weekly Completion</span>
                  <span className="text-white font-medium">{stats?.weeklyCompletion || 0}%</span>
                </div>
                <ProgressBar value={stats?.weeklyCompletion || 0} className="h-2.5 bg-dark-lighter" />
              </>
            )}
            
            <div className="mt-4 grid grid-cols-2 gap-3">
              <div className="bg-dark-lighter rounded-lg p-3">
                <span className="text-gray-400 text-xs block">Current Streak</span>
                <div className="flex items-center mt-1">
                  <Flame className="h-5 w-5 text-amber-500 mr-1" />
                  <span className="text-white font-medium">
                    {isLoadingStats ? (
                      <Skeleton className="h-4 w-12 bg-dark" />
                    ) : (
                      `${stats?.currentStreak || 0} days`
                    )}
                  </span>
                </div>
              </div>
              <div className="bg-dark-lighter rounded-lg p-3">
                <span className="text-gray-400 text-xs block">Today</span>
                <div className="flex items-center mt-1">
                  <Star className="h-5 w-5 text-green-500 mr-1" />
                  <span className="text-white font-medium">
                    {isLoadingStats ? (
                      <Skeleton className="h-4 w-12 bg-dark" />
                    ) : (
                      `${stats?.completedToday || 0}/${stats?.totalHabits || 0}`
                    )}
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Tabs defaultValue="weekly" className="w-full">
          <TabsList className="w-full bg-dark-lighter mb-4">
            <TabsTrigger value="weekly" className="flex-1 data-[state=active]:bg-primary data-[state=active]:text-white">
              Weekly
            </TabsTrigger>
            <TabsTrigger value="monthly" className="flex-1 data-[state=active]:bg-primary data-[state=active]:text-white">
              Monthly
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="weekly">
            <Card className="bg-dark-card text-white border-dark-lighter">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Last 7 Days</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={last7DaysData}
                      margin={{ top: 10, right: 10, left: -20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#2A2A2A" />
                      <XAxis dataKey="day" tick={{ fill: '#e0e0e0' }} />
                      <YAxis tick={{ fill: '#e0e0e0' }} />
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#1E1E1E', border: 'none' }}
                        labelStyle={{ color: 'white' }}
                      />
                      <Bar dataKey="completed" fill="#E91E63" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="monthly">
            <Card className="bg-dark-card text-white border-dark-lighter">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Monthly Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={monthlyData}
                      margin={{ top: 10, right: 10, left: -20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#2A2A2A" />
                      <XAxis dataKey="date" tick={{ fill: '#e0e0e0' }} />
                      <YAxis tick={{ fill: '#e0e0e0' }} />
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#1E1E1E', border: 'none' }}
                        labelStyle={{ color: 'white' }}
                      />
                      <Bar dataKey="completed" fill="#9C27B0" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
