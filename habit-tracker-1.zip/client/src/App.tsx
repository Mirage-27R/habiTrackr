import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Calendar from "@/pages/Calendar";
import Progress from "@/pages/Progress";
import Journal from "@/pages/Journal";
import AllHabits from "@/pages/AllHabits";
import Settings from "@/pages/Settings";
import BottomNavigation from "@/components/BottomNavigation";
import SplashScreen from "@/components/SplashScreen";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { STORAGE_KEYS, THEMES } from "@/lib/constants";

function App() {
  const [location] = useLocation();
  const [activeTab, setActiveTab] = useState("home");
  const [isHomeSwipeUp, setIsHomeSwipeUp] = useState(false);
  // This ensures splash screen shows every time the app is loaded
  const [showSplash, setShowSplash] = useState(true);
  const [isFirstLoad, setIsFirstLoad] = useState(true);
  const [settings, setSettings] = useState({}); // Added state for settings

  // Update the active tab based on location
  useEffect(() => {
    if (location === "/" || location === "/home") {
      setActiveTab("home");
    } else if (location === "/calendar") {
      setActiveTab("calendar");
    } else if (location === "/habits") {
      setActiveTab("habits");
    } else if (location === "/progress") {
      setActiveTab("progress");
    } else if (location === "/journal") {
      setActiveTab("journal");
    } else if (location === "/settings") {
      setActiveTab("settings");
    }
  }, [location]);

  // Initialize theme and settings from saved settings
  useEffect(() => {
    const savedSettings = localStorage.getItem(STORAGE_KEYS.WIDGET_SETTINGS);
    if (savedSettings) {
      try {
        const settings = JSON.parse(savedSettings);
        setSettings(settings);
        const themeKey = settings.theme || "BLUE";
        const theme = THEMES[themeKey];
        
        if (theme) {
          // Apply theme colors
          document.documentElement.style.setProperty('--color-primary', theme.PRIMARY);
          document.documentElement.style.setProperty('--color-secondary', theme.SECONDARY);
          document.documentElement.style.setProperty('--color-primary-rgb', theme.PRIMARY_RGB);
          document.documentElement.style.setProperty('--color-secondary-rgb', theme.SECONDARY_RGB);
          
          // Convert HSL to space-separated values for shadcn
          const primaryMatch = theme.PRIMARY.match(/hsl\((\d+),\s*(\d+)%,\s*(\d+)%\)/);
          const secondaryMatch = theme.SECONDARY.match(/hsl\((\d+),\s*(\d+)%,\s*(\d+)%\)/);
          
          if (primaryMatch) {
            document.documentElement.style.setProperty('--primary', `${primaryMatch[1]} ${primaryMatch[2]}% ${primaryMatch[3]}%`);
            document.documentElement.style.setProperty('--accent', `${primaryMatch[1]} ${primaryMatch[2]}% ${primaryMatch[3]}%`);
          }
          
          if (secondaryMatch) {
            document.documentElement.style.setProperty('--secondary', `${secondaryMatch[1]} ${secondaryMatch[2]}% ${secondaryMatch[3]}%`);
          }
        }
      } catch (error) {
        console.error("Error applying theme:", error);
      }
    } else {
      // Initialize with default settings
      const defaultSettings = { theme: "BLUE" };
      localStorage.setItem(STORAGE_KEYS.WIDGET_SETTINGS, JSON.stringify(defaultSettings));
      setSettings(defaultSettings);
    }
  }, []);

  // Initialize notifications
  useEffect(() => {
    // Register service worker for notifications (would be implemented in a full app)
    console.log("Service worker registration would go here in a full implementation");

    // Create a warning for notification permissions in browsers that don't support it
    if (!('Notification' in window)) {
      console.warn("This browser does not support notifications");
    }
  }, []);

  // Handle first load with splash screen
  useEffect(() => {
    if (isFirstLoad) {
      // Show splash screen for exactly 2 seconds on first load
      setShowSplash(true);
      const timer = setTimeout(() => {
        setShowSplash(false);
        setIsFirstLoad(false);
      }, 2000);

      return () => clearTimeout(timer);
    }
  }, [isFirstLoad]);

  // Track touch gestures for home page swipe up
  useEffect(() => {
    let startY = 0;
    let currentY = 0;

    const handleTouchStart = (e: TouchEvent) => {
      startY = e.touches[0].clientY;
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (location === "/" || location === "/home") {
        currentY = e.touches[0].clientY;
        const diffY = startY - currentY;

        // If swiping up and the difference is significant
        if (diffY > 50) {
          setIsHomeSwipeUp(true);
        } else if (diffY < -50) {
          setIsHomeSwipeUp(false);
        }
      }
    };

    document.addEventListener('touchstart', handleTouchStart);
    document.addEventListener('touchmove', handleTouchMove);

    return () => {
      document.removeEventListener('touchstart', handleTouchStart);
      document.removeEventListener('touchmove', handleTouchMove);
    };
  }, [location]);

  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen bg-dark pb-16">
        {showSplash ? (
          <SplashScreen onDone={() => setShowSplash(false)} />
        ) : (
          <>
            <div className={`transition-transform duration-300 ${isHomeSwipeUp ? 'transform -translate-y-12' : ''}`}>
              <Switch>
                <Route path="/" component={() => <Home userName={settings.userName} />} />
                <Route path="/habits" component={AllHabits} />
                <Route path="/progress" component={Progress} />
                <Route path="/journal" component={Journal} />
                <Route path="/calendar" component={Calendar} />
                <Route path="/settings" component={Settings} />
                <Route path="/:rest*" component={NotFound} />
              </Switch>
            </div>
            <BottomNavigation activeTab={activeTab} />
          </>
        )}
        <Toaster />
      </div>
    </QueryClientProvider>
  );
}

export default App;