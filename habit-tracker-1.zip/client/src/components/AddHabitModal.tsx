import React, { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { X, Plus } from "lucide-react";
import { DaysOfWeek, Categories, insertHabitSchema } from "@shared/schema";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { z } from "zod";
import { cn } from "@/lib/utils";

interface AddHabitModalProps {
  isOpen: boolean;
  onClose: () => void;
}

// Extend the insert schema with proper validation
const formSchema = insertHabitSchema.extend({
  name: z.string().min(1, "Name is required").max(50, "Name is too long"),
  description: z.string().max(200, "Description is too long").optional(),
  repeatDays: z.array(z.string()).min(1, "Select at least one day"),
  reminderTimes: z.array(z.string()).optional(),
});

type FormValues = z.infer<typeof formSchema>;

export default function AddHabitModal({ isOpen, onClose }: AddHabitModalProps) {
  const { toast } = useToast();
  const [selectedCategory, setSelectedCategory] = useState<string>(Categories[0]);
  const [reminders, setReminders] = useState<string[]>(["08:00"]);
  const [reminderInput, setReminderInput] = useState<string>("08:00");
  
  // Initialize form with default values
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      description: "",
      category: Categories[0],
      repeatDays: ["Monday", "Wednesday", "Friday"],
      reminderTimes: ["08:00"],
      isActive: true,
      isPreset: false,
      icon: "check",
    },
  });
  
  // Add habit mutation
  const addHabit = useMutation({
    mutationFn: async (values: FormValues) => {
      const response = await fetch('/api/habits', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(values),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to create habit');
      }
      
      return response.json();
    },
    onSuccess: () => {
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/habits'] });
      queryClient.invalidateQueries({ queryKey: ['/api/habits/with-completion/today'] });
      
      toast({
        title: "Habit created",
        description: "Your new habit has been added successfully",
      });
      
      // Reset form and close modal
      form.reset();
      onClose();
    },
    onError: (error) => {
      console.error("Error creating habit:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to create habit. Please try again.",
        variant: "destructive",
      });
    }
  });
  
  // Handle form submission
  const onSubmit = (values: FormValues) => {
    // Add reminders to the form values
    values.reminderTimes = reminders;
    // Add selected category
    values.category = selectedCategory as any;
    
    addHabit.mutate(values);
  };
  
  // Handle adding a new reminder time
  const handleAddReminder = () => {
    if (reminderInput && !reminders.includes(reminderInput)) {
      setReminders([...reminders, reminderInput]);
    }
  };
  
  // Handle removing a reminder time
  const handleRemoveReminder = (time: string) => {
    setReminders(reminders.filter(t => t !== time));
  };
  
  // Handle toggling a day of the week
  const toggleDay = (day: string) => {
    const currentDays = form.getValues().repeatDays || [];
    
    if (currentDays.includes(day)) {
      // Remove day if already selected
      form.setValue('repeatDays', currentDays.filter(d => d !== day));
    } else {
      // Add day if not selected
      form.setValue('repeatDays', [...currentDays, day]);
    }
  };
  
  // Check if a day is selected
  const isDaySelected = (day: string) => {
    return (form.getValues().repeatDays || []).includes(day);
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-dark-card text-white border-dark-lighter max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold text-white">Add New Habit</DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-400">Name</FormLabel>
                  <FormControl>
                    <Input 
                      {...field} 
                      className="bg-dark-lighter border-none text-white focus:ring-2 focus:ring-primary/50" 
                      placeholder="Habit name"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-400">Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field} 
                      className="bg-dark-lighter border-none text-white focus:ring-2 focus:ring-primary/50" 
                      placeholder="Description" 
                      rows={3}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="mb-4">
              <label className="block text-gray-400 mb-1 text-sm">Category</label>
              <div className="flex flex-wrap gap-2">
                {Categories.map((category) => (
                  <button 
                    key={category}
                    type="button" 
                    className={cn(
                      "px-3 py-1.5 rounded-full text-sm",
                      selectedCategory === category 
                        ? "bg-primary/20 text-primary" 
                        : "bg-dark-lighter text-gray-400"
                    )}
                    onClick={() => setSelectedCategory(category)}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="mb-4">
              <label className="block text-gray-400 mb-1 text-sm">Reminders</label>
              {reminders.map((time) => (
                <div key={time} className="flex items-center mb-2">
                  <div className="bg-dark-lighter rounded px-3 py-1.5 text-white flex-grow flex items-center justify-between">
                    <span>{time}</span>
                    <button 
                      type="button" 
                      className="text-gray-400 hover:text-destructive"
                      onClick={() => handleRemoveReminder(time)}
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
              <div className="flex items-center">
                <Input
                  type="time"
                  className="bg-dark-lighter border-none text-white mr-2 flex-grow focus:ring-2 focus:ring-primary/50"
                  value={reminderInput}
                  onChange={(e) => setReminderInput(e.target.value)}
                />
                <Button 
                  type="button" 
                  variant="ghost"
                  className="p-2 bg-primary/20 text-primary rounded-lg h-10 w-10"
                  onClick={handleAddReminder}
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            <FormField
              control={form.control}
              name="repeatDays"
              render={() => (
                <FormItem>
                  <FormLabel className="text-gray-400">Repeat</FormLabel>
                  <div className="flex justify-between">
                    {DaysOfWeek.map((day) => (
                      <Button
                        key={day}
                        type="button"
                        className={cn(
                          "w-9 h-9 rounded-full flex items-center justify-center text-sm font-medium p-0",
                          isDaySelected(day)
                            ? "bg-primary text-white"
                            : "bg-dark-lighter text-gray-400"
                        )}
                        onClick={() => toggleDay(day)}
                      >
                        {day.charAt(0)}
                      </Button>
                    ))}
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Button 
              type="submit" 
              className="w-full bg-primary text-white py-3 rounded-lg font-medium mt-2"
              disabled={addHabit.isPending}
            >
              {addHabit.isPending ? "Creating..." : "Create Habit"}
            </Button>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
