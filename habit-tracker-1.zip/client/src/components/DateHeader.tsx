import React from "react";
import { formatDate } from "@/lib/utils";

interface DateHeaderProps {
  date: Date;
}

export default function DateHeader({ date }: DateHeaderProps) {
  return (
    <div className="p-4 text-gray-400 uppercase text-sm font-medium tracking-wider">
      {formatDate(date)}
    </div>
  );
}
