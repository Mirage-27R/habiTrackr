import React from "react";
import { cn } from "@/lib/utils";
import { useLocation } from "wouter";

interface TabNavigationProps {
  activeTab: string;
}

const tabs = [
  { id: "home", label: "My Habits", href: "/" },
  { id: "calendar", label: "Calendar", href: "/calendar" },
  { id: "progress", label: "Progress", href: "/progress" },
  { id: "settings", label: "Settings", href: "/settings" },
];

export default function TabNavigation({ activeTab }: TabNavigationProps) {
  const [, navigate] = useLocation();

  return (
    <div className="flex px-4 py-2 overflow-x-auto space-x-2 border-b border-dark-lighter">
      {tabs.map((tab) => (
        <div key={tab.id} className="inline-block">
          <button
            onClick={() => navigate(tab.href)}
            className={cn(
              "px-4 py-2 rounded-lg text-sm font-medium transition-colors",
              activeTab === tab.id 
                ? "bg-primary text-white" 
                : "bg-dark-card text-gray-400 hover:text-gray-200"
            )}
          >
            {tab.label}
          </button>
        </div>
      ))}
    </div>
  );
}
