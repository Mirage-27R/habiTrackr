import React from "react";
import { HabitStats } from "@shared/schema";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Flame, TrendingUp } from "lucide-react";

interface ProgressStatsProps {
  stats?: HabitStats;
  isLoading: boolean;
}

export default function ProgressStats({ stats, isLoading }: ProgressStatsProps) {
  return (
    <div className="mt-6 p-4">
      <h2 className="text-lg font-semibold mb-3 text-white">Today's Progress</h2>
      <div className="bg-dark-card rounded-lg p-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-gray-400">Daily Completion</span>
          {isLoading ? (
            <Skeleton className="h-4 w-12 bg-dark-lighter" />
          ) : (
            <span className="text-white font-medium">
              {stats?.completedToday || 0}/{stats?.totalHabits || 0}
            </span>
          )}
        </div>
        
        {isLoading ? (
          <Skeleton className="h-2.5 w-full bg-dark-lighter" />
        ) : (
          <Progress 
            value={stats?.totalHabits ? (stats.completedToday / stats.totalHabits) * 100 : 0} 
            className="bg-dark-lighter h-2.5"
          />
        )}
        
        <div className="mt-4 grid grid-cols-2 gap-3">
          <div className="bg-dark-lighter rounded-lg p-3">
            <span className="text-gray-400 text-xs block">Current Streak</span>
            <div className="flex items-center mt-1">
              <Flame className="text-amber-500 mr-1 h-5 w-5" />
              {isLoading ? (
                <Skeleton className="h-4 w-12 bg-dark" />
              ) : (
                <span className="text-white font-medium">{stats?.currentStreak || 0} days</span>
              )}
            </div>
          </div>
          <div className="bg-dark-lighter rounded-lg p-3">
            <span className="text-gray-400 text-xs block">This Week</span>
            <div className="flex items-center mt-1">
              <TrendingUp className="text-green-500 mr-1 h-5 w-5" />
              {isLoading ? (
                <Skeleton className="h-4 w-12 bg-dark" />
              ) : (
                <span className="text-white font-medium">{stats?.weeklyCompletion || 0}%</span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
