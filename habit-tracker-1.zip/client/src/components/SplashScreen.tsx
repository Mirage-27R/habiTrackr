import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { APP_NAME } from '@/lib/constants';

interface SplashScreenProps {
  onDone: () => void;
}

export default function SplashScreen({ onDone }: SplashScreenProps) {
  const [progress, setProgress] = useState(0);
  
  useEffect(() => {
    // Automatically dismiss the splash screen after exactly 2 seconds
    const duration = 2000;
    const startTime = Date.now();
    
    const timer = setTimeout(() => {
      onDone();
    }, duration);
    
    // Create loading progress animation
    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const newProgress = Math.min(100, (elapsed / duration) * 100);
      setProgress(newProgress);
      
      if (newProgress >= 100) {
        clearInterval(interval);
      }
    }, 50);
    
    return () => {
      clearTimeout(timer);
      clearInterval(interval);
    };
  }, [onDone]);
  
  return (
    <motion.div 
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.1, duration: 0.5 }}
        className="flex flex-col items-center"
      >
        {/* App Logo - Circle with animated checkmark */}
        <motion.div 
          className="w-32 h-32 rounded-full mb-8 flex items-center justify-center relative overflow-hidden"
          style={{ backgroundColor: 'var(--color-primary)' }}
          initial={{ rotate: -10 }}
          animate={{ rotate: 0 }}
          transition={{ delay: 0.3, type: "spring", stiffness: 100 }}
        >
          <motion.svg 
            xmlns="http://www.w3.org/2000/svg" 
            width="64" 
            height="64" 
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="2.5" 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            className="text-white"
            initial={{ pathLength: 0, opacity: 0 }}
            animate={{ pathLength: 1, opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.8 }}
          >
            <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"/>
            <motion.path 
              d="m7 13 3 3 7-7"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ delay: 0.8, duration: 0.6 }}
            />
          </motion.svg>
        </motion.div>
        
        {/* App Name */}
        <motion.h1 
          className="text-4xl font-bold mb-3 text-white"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.5 }}
        >
          {APP_NAME}
        </motion.h1>
        
        {/* Creator Credit */}
        <motion.p 
          className="text-base"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.5 }}
          style={{ color: 'var(--color-primary)' }}
        >
          made by rasa sarvi
        </motion.p>
        
        {/* Loading Progress Bar */}
        <motion.div className="w-48 h-1 bg-gray-800 rounded-full mt-8 overflow-hidden">
          <motion.div 
            className="h-full rounded-full"
            style={{ 
              backgroundColor: 'var(--color-primary)',
              width: `${progress}%` 
            }}
            initial={{ width: "0%" }}
            animate={{ width: `${progress}%` }}
          />
        </motion.div>
      </motion.div>
    </motion.div>
  );
}