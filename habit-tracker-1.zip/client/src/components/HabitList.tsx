import React from "react";
import { HabitWithCompletion } from "@shared/schema";
import HabitItem from "./HabitItem";
import { Skeleton } from "@/components/ui/skeleton";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient, useMutation } from '@tanstack/react-query';

interface HabitListProps {
  habits: HabitWithCompletion[];
  isLoading: boolean;
  onToggleHabit: (id: number, completed: boolean) => void;
  isPending: boolean;
  showEmptyMessage?: boolean;
  emptyMessage?: string;
  enableDrag?: boolean;
}

export default function HabitList({ 
  habits, 
  isLoading, 
  onToggleHabit, 
  isPending,
  showEmptyMessage = true,
  emptyMessage = "No habits to display for today",
  enableDrag = true
}: HabitListProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const toggleHabitMutation = useMutation({
    mutationFn: ({ id, completed }: { id: number; completed: boolean }) => {
      return fetch(`/api/habits/${id}/complete`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ completed })
      }).then(res => {
        if (!res.ok) {
          throw new Error(`HTTP error! status: ${res.status}`);
        }
        return res.json();
      });
    },
    onError: (error) => {
      console.error("Habit completion error:", error);
      toast({
        title: "Error",
        description: "Failed to update habit completion status. Please try again.",
        variant: "destructive",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/habits/with-completion/today'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
    }
  });

  const handleDragEnd = (result: any) => {
    if (!result.destination) return;

    const items = Array.from(habits);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    toast({
      title: "Habit reordered",
      description: `${reorderedItem.name} has been moved to position ${result.destination.index + 1}`,
    });
  };

  if (isLoading) {
    return (
      <div className="px-4 space-y-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className="bg-dark-card rounded-lg p-4">
            <div className="flex items-start">
              <div className="flex-shrink-0 mr-4">
                <Skeleton className="w-6 h-6 rounded-full bg-dark-lighter" />
              </div>
              <div className="flex-grow">
                <div className="flex items-center space-x-2">
                  <Skeleton className="h-6 w-36 bg-dark-lighter" />
                  <Skeleton className="h-4 w-16 bg-dark-lighter" />
                </div>
                <Skeleton className="h-4 w-full mt-2 bg-dark-lighter" />
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (habits.length === 0 && showEmptyMessage) {
    return (
      <div className="px-4 py-8 text-center text-gray-400">
        <p>{emptyMessage}</p>
      </div>
    );
  }

  if (enableDrag) {
    return (
      <div className="px-4">
        <DragDropContext onDragEnd={handleDragEnd}>
          <Droppable droppableId="habit-list">
            {(provided) => (
              <div 
                className="space-y-4" 
                {...provided.droppableProps}
                ref={provided.innerRef}
              >
                {habits.map((habit, index) => (
                  <Draggable 
                    key={habit.id} 
                    draggableId={`habit-${habit.id}`} 
                    index={index}
                  >
                    {(provided) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                      >
                        <HabitItem 
                          habit={habit} 
                          onToggle={() => toggleHabitMutation.mutate({ id: habit.id, completed: !habit.completed })} 
                          disabled={isPending}
                          draggable={true}
                          dragHandleProps={provided.dragHandleProps}
                        />
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </DragDropContext>
      </div>
    );
  }

  return (
    <div className="px-4 space-y-4">
      {habits.map((habit) => (
        <HabitItem 
          key={habit.id} 
          habit={habit} 
          onToggle={() => toggleHabitMutation.mutate({ id: habit.id, completed: !habit.completed })} 
          disabled={isPending}
        />
      ))}
    </div>
  );
}