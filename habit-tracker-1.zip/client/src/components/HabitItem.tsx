import React from "react";
import { HabitWithCompletion } from "@shared/schema";
import { cn } from "@/lib/utils";
import { GripVertical } from "lucide-react";

interface HabitItemProps {
  habit: HabitWithCompletion;
  onToggle: (id: number, completed: boolean) => void;
  disabled?: boolean;
  draggable?: boolean;
  dragHandleProps?: any;
}

export default function HabitItem({ 
  habit, 
  onToggle, 
  disabled = false,
  draggable = false,
  dragHandleProps
}: HabitItemProps) {
  const { id, name, description, category, isCompletedToday } = habit;

  const handleToggle = () => {
    if (!disabled) {
      onToggle(id, !isCompletedToday);
    }
  };

  return (
    <div className={cn(
      "bg-dark-card rounded-lg p-4",
      isCompletedToday && "opacity-70"
    )}>
      <div className="flex items-start">
        {draggable && (
          <div 
            className="flex-shrink-0 mr-2 cursor-grab active:cursor-grabbing flex items-center justify-center h-full pt-1" 
            {...dragHandleProps}
          >
            <GripVertical className="h-5 w-5 text-gray-500" />
          </div>
        )}
        <div className="flex-shrink-0 mr-4">
          <input 
            type="checkbox" 
            className="habit-checkbox" 
            checked={isCompletedToday} 
            onChange={handleToggle}
            disabled={disabled}
          />
        </div>
        <div className="flex-grow">
          <div className="flex items-center space-x-2">
            <h3 className="text-primary text-lg font-medium">{name}</h3>
            <span 
              className="px-2 py-0.5 rounded text-xs"
              style={{ 
                backgroundColor: `var(--color-primary-20)`, 
                color: `var(--color-primary)` 
              }}
            >
              {category}
            </span>
          </div>
          {description && (
            <p className="text-gray-400 mt-1">{description}</p>
          )}
        </div>
      </div>
    </div>
  );
}