import React from "react";
import { generateAvatarUrl } from "@/lib/utils";
import { ChevronDown, Bell, Settings } from "lucide-react";

interface AppHeaderProps {
  userName: string;
}

export default function AppHeader({ userName }: AppHeaderProps) {
  const avatarUrl = generateAvatarUrl(userName);
  
  return (
    <header className="bg-primary p-4 flex items-center justify-between">
      <div className="flex items-center space-x-2">
        <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center overflow-hidden">
          <img src={avatarUrl} alt={userName} className="w-full h-full object-cover" />
        </div>
        <div className="flex items-center space-x-1">
          <span className="font-medium text-white">{userName}</span>
          <ChevronDown className="text-white h-4 w-4" />
        </div>
      </div>
      <div className="flex space-x-1">
        <button className="p-1">
          <Bell className="text-white h-5 w-5" />
        </button>
        <button className="p-1" onClick={() => window.location.href = '/settings'}>
          <Settings className="text-white h-5 w-5" />
        </button>
      </div>
    </header>
  );
}
