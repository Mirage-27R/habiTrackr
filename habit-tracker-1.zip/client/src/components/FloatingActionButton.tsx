import React from "react";
import { Plus } from "lucide-react";

interface FloatingActionButtonProps {
  onClick: () => void;
}

export default function FloatingActionButton({ onClick }: FloatingActionButtonProps) {
  return (
    <button 
      className="fixed right-6 bottom-20 w-14 h-14 rounded-full bg-primary shadow-lg flex items-center justify-center" 
      onClick={onClick}
      aria-label="Add new habit"
    >
      <Plus className="h-6 w-6 text-white" />
    </button>
  );
}
