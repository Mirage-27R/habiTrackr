import React from "react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Home, ListChecks, TrendingUp, BookOpen } from "lucide-react";

interface BottomNavigationProps {
  activeTab: string;
}

const navItems = [
  { id: "home", label: "Home", icon: Home, href: "/" },
  { id: "habits", label: "Habits", icon: ListChecks, href: "/habits" },
  { id: "progress", label: "Progress", icon: TrendingUp, href: "/progress" },
  { id: "journal", label: "Journal", icon: BookOpen, href: "/journal" },
];

export default function BottomNavigation({ activeTab }: BottomNavigationProps) {
  const [, navigate] = useLocation();
  
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-dark-card border-t border-dark-lighter flex justify-around py-3">
      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive = activeTab === item.id;
        
        return (
          <button
            key={item.id}
            onClick={() => navigate(item.href)}
            className={cn(
              "flex flex-col items-center bg-transparent border-none cursor-pointer",
              isActive ? "text-primary" : "text-gray-500"
            )}
          >
            <Icon className="h-5 w-5" />
            <span className="text-xs mt-1">{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
}
