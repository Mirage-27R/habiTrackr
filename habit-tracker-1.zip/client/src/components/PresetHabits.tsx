import React from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { Habit } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Plus } from "lucide-react";

export default function PresetHabits() {
  const { toast } = useToast();
  
  // Fetch preset habits
  const { 
    data: presetHabits, 
    isLoading 
  } = useQuery<Habit[]>({
    queryKey: ['/api/habits/presets'],
  });
  
  // Add preset habit mutation
  const addPresetHabit = useMutation({
    mutationFn: async (habitId: number) => {
      // Get the preset habit details
      const presetResponse = await fetch(`/api/habits/${habitId}`);
      if (!presetResponse.ok) {
        throw new Error('Failed to fetch preset habit details');
      }
      
      const presetHabit = await presetResponse.json();
      
      // Create a new habit based on the preset
      const newHabit = {
        ...presetHabit,
        isPreset: false, // This is a user habit now, not a preset
      };
      
      // Delete the id, createdAt as they will be generated server-side
      delete newHabit.id;
      delete newHabit.createdAt;
      
      const response = await fetch('/api/habits', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newHabit),
      });
      
      if (!response.ok) {
        throw new Error('Failed to add habit');
      }
      
      return response.json();
    },
    onSuccess: () => {
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/habits'] });
      queryClient.invalidateQueries({ queryKey: ['/api/habits/with-completion/today'] });
      
      toast({
        title: "Habit added",
        description: "The habit has been added to your list",
      });
    },
    onError: (error) => {
      console.error("Error adding preset habit:", error);
      toast({
        title: "Error",
        description: "Failed to add the habit. Please try again.",
        variant: "destructive",
      });
    }
  });
  
  // Handle adding a preset habit
  const handleAddPreset = (habitId: number) => {
    addPresetHabit.mutate(habitId);
  };
  
  // Create array of presets or loading placeholders
  const presetsToRender = isLoading
    ? Array(4).fill(null)
    : presetHabits || [];
  
  return (
    <div className="mt-4 p-4">
      <div className="flex justify-between items-center mb-3">
        <h2 className="text-lg font-semibold text-white">Suggested Habits</h2>
        <button className="text-primary text-sm">See All</button>
      </div>
      
      <div className="overflow-x-auto pb-2">
        <div className="flex space-x-3">
          {presetsToRender.map((preset, index) => (
            <div key={preset?.id || index} className="bg-dark-card rounded-lg p-3 min-w-[150px]">
              {isLoading ? (
                <>
                  <Skeleton className="mb-2 w-8 h-8 rounded-full bg-dark-lighter" />
                  <Skeleton className="h-4 w-20 mb-1 bg-dark-lighter" />
                  <Skeleton className="h-3 w-24 mb-2 bg-dark-lighter" />
                  <Skeleton className="h-6 w-16 bg-dark-lighter" />
                </>
              ) : (
                <>
                  <div className="mb-2 bg-primary/20 w-8 h-8 rounded-full flex items-center justify-center">
                    <span className="material-icons text-primary">{preset.icon}</span>
                  </div>
                  <h3 className="text-white font-medium">{preset.name}</h3>
                  <p className="text-gray-400 text-sm">{preset.description?.substring(0, 20)}...</p>
                  <Button
                    className="mt-2 bg-primary/20 text-primary text-xs py-1 px-2 rounded-full h-auto"
                    onClick={() => handleAddPreset(preset.id)}
                    disabled={addPresetHabit.isPending}
                    variant="ghost"
                    size="sm"
                  >
                    {addPresetHabit.isPending && addPresetHabit.variables === preset.id ? (
                      "Adding..."
                    ) : (
                      <>
                        <Plus className="h-3 w-3 mr-1" />
                        Add
                      </>
                    )}
                  </Button>
                </>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
