import { 
  Habit, 
  HabitCompletion, 
  HabitWithCompletion, 
  InsertHabit, 
  InsertHabitCompletion, 
  HabitStats,
  DaysOfWeek,
} from "@shared/schema";
import { format, isToday, parseISO, startOfToday, subDays, isEqual, differenceInDays } from "date-fns";

// Define interface for our storage operations
export interface IStorage {
  // Habit CRUD operations
  getHabits(): Promise<Habit[]>;
  getHabitsByDay(day: string): Promise<Habit[]>;
  getPresetHabits(): Promise<Habit[]>;
  getHabit(id: number): Promise<Habit | undefined>;
  createHabit(habit: InsertHabit): Promise<Habit>;
  updateHabit(id: number, habit: Partial<InsertHabit>): Promise<Habit | undefined>;
  deleteHabit(id: number): Promise<boolean>;
  
  // Habit completion operations
  getHabitsWithTodayCompletion(): Promise<HabitWithCompletion[]>;
  markHabitAsCompleted(habitId: number, completed: boolean): Promise<HabitCompletion>;
  getHabitCompletions(habitId: number, days?: number): Promise<HabitCompletion[]>;
  
  // Stats
  getHabitStats(): Promise<HabitStats>;
}

// Memory storage implementation
export class MemStorage implements IStorage {
  private habits: Map<number, Habit>;
  private completions: Map<number, HabitCompletion>;
  private habitIdCounter: number;
  private completionIdCounter: number;

  constructor() {
    this.habits = new Map();
    this.completions = new Map();
    this.habitIdCounter = 1;
    this.completionIdCounter = 1;
    
    // Initialize with some preset habits
    this.initializePresets();
  }

  private initializePresets() {
    const presets: InsertHabit[] = [
      {
        name: "Morning Run",
        description: "5km run every morning for 30 minutes",
        category: "Sport",
        repeatDays: ["Monday", "Wednesday", "Friday"],
        reminderTimes: ["06:30"],
        isPreset: true,
        icon: "directions_run",
        isActive: true
      },
      {
        name: "Drink Water",
        description: "Drink 2 liters of water throughout the day",
        category: "Health",
        repeatDays: DaysOfWeek,
        reminderTimes: ["09:00", "12:00", "15:00", "18:00"],
        isPreset: true,
        icon: "water_drop",
        isActive: true
      },
      {
        name: "Read a Book",
        description: "Read for 30 minutes before bed",
        category: "Personal",
        repeatDays: DaysOfWeek,
        reminderTimes: ["21:00"],
        isPreset: true,
        icon: "menu_book",
        isActive: true
      },
      {
        name: "Meditate",
        description: "10 minutes of mindfulness meditation",
        category: "Wellness",
        repeatDays: DaysOfWeek,
        reminderTimes: ["07:00", "20:00"],
        isPreset: true,
        icon: "self_improvement",
        isActive: true
      },
      {
        name: "Learn a Language",
        description: "Practice a new language for 15 minutes",
        category: "Education",
        repeatDays: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
        reminderTimes: ["19:00"],
        isPreset: true,
        icon: "translate",
        isActive: true
      }
    ];

    // Add presets to storage
    presets.forEach(preset => this.createHabit(preset));
    
    // Mark some habits as completed for today
    setTimeout(() => {
      this.markHabitAsCompleted(1, true);
      this.markHabitAsCompleted(2, true);
    }, 100);
  }

  async getHabits(): Promise<Habit[]> {
    return Array.from(this.habits.values());
  }

  async getHabitsByDay(day: string): Promise<Habit[]> {
    return Array.from(this.habits.values()).filter(
      habit => habit.isActive && habit.repeatDays.includes(day as any)
    );
  }

  async getPresetHabits(): Promise<Habit[]> {
    return Array.from(this.habits.values()).filter(habit => habit.isPreset);
  }

  async getHabit(id: number): Promise<Habit | undefined> {
    return this.habits.get(id);
  }

  async createHabit(insertHabit: InsertHabit): Promise<Habit> {
    const id = this.habitIdCounter++;
    const today = new Date();
    const createdAt = format(today, 'yyyy-MM-dd');
    
    const habit: Habit = {
      ...insertHabit,
      id,
      createdAt,
    };
    
    this.habits.set(id, habit);
    return habit;
  }

  async updateHabit(id: number, updates: Partial<InsertHabit>): Promise<Habit | undefined> {
    const habit = this.habits.get(id);
    if (!habit) return undefined;
    
    const updatedHabit: Habit = { ...habit, ...updates };
    this.habits.set(id, updatedHabit);
    return updatedHabit;
  }

  async deleteHabit(id: number): Promise<boolean> {
    return this.habits.delete(id);
  }

  async getHabitsWithTodayCompletion(): Promise<HabitWithCompletion[]> {
    const today = format(new Date(), 'yyyy-MM-dd');
    const habits = await this.getHabits();
    
    // Get all completions for today
    const todayCompletions = Array.from(this.completions.values()).filter(
      completion => format(new Date(completion.completedDate), 'yyyy-MM-dd') === today
    );
    
    // Map habits to include completion status
    return habits
      .filter(habit => habit.isActive)
      .map(habit => {
        const completionForHabit = todayCompletions.find(
          completion => completion.habitId === habit.id
        );
        
        return {
          ...habit,
          isCompletedToday: completionForHabit ? completionForHabit.completed : false
        };
      });
  }

  async markHabitAsCompleted(habitId: number, completed: boolean): Promise<HabitCompletion> {
    const today = new Date();
    const todayStr = format(today, 'yyyy-MM-dd');
    
    // Check if there's already a completion record for this habit today
    const existingCompletion = Array.from(this.completions.values()).find(
      completion => 
        completion.habitId === habitId && 
        format(new Date(completion.completedDate), 'yyyy-MM-dd') === todayStr
    );
    
    if (existingCompletion) {
      // Update existing completion
      existingCompletion.completed = completed;
      this.completions.set(existingCompletion.id, existingCompletion);
      return existingCompletion;
    } else {
      // Create new completion record
      const id = this.completionIdCounter++;
      const completion: HabitCompletion = {
        id,
        habitId,
        completedDate: todayStr,
        completed
      };
      
      this.completions.set(id, completion);
      return completion;
    }
  }

  async getHabitCompletions(habitId: number, days = 30): Promise<HabitCompletion[]> {
    const today = new Date();
    const oldest = subDays(today, days);
    
    return Array.from(this.completions.values()).filter(
      completion => 
        completion.habitId === habitId && 
        new Date(completion.completedDate) >= oldest
    );
  }

  async getHabitStats(): Promise<HabitStats> {
    const habitsWithCompletion = await this.getHabitsWithTodayCompletion();
    const activeHabits = habitsWithCompletion.filter(h => h.isActive);
    
    // Count completed habits today
    const completedToday = habitsWithCompletion.filter(h => h.isCompletedToday).length;
    
    // Calculate current streak
    let currentStreak = 0;
    const today = startOfToday();
    let checkDate = today;
    let streakBroken = false;
    
    // Check past 30 days to find streak
    for (let i = 0; i < 30 && !streakBroken; i++) {
      const dateStr = format(checkDate, 'yyyy-MM-dd');
      const dayCompletions = Array.from(this.completions.values()).filter(
        completion => format(new Date(completion.completedDate), 'yyyy-MM-dd') === dateStr
      );
      
      // For a day to count for streak, at least one habit must be completed
      if (dayCompletions.some(c => c.completed)) {
        currentStreak++;
        checkDate = subDays(checkDate, 1);
      } else {
        streakBroken = true;
      }
    }
    
    // Calculate weekly completion percentage (past 7 days)
    const past7Days = Array.from({ length: 7 }, (_, i) => format(subDays(today, i), 'yyyy-MM-dd'));
    const completionsLast7Days = Array.from(this.completions.values()).filter(
      c => past7Days.includes(format(new Date(c.completedDate), 'yyyy-MM-dd'))
    );
    
    // Total possible habit completions in last 7 days
    const totalPossible = activeHabits.length * 7;
    // Actual completions
    const actualCompletions = completionsLast7Days.filter(c => c.completed).length;
    
    // Calculate percentage, handle case where no habits exist
    const weeklyCompletion = totalPossible > 0 
      ? Math.round((actualCompletions / totalPossible) * 100) 
      : 0;
    
    return {
      totalHabits: activeHabits.length,
      completedToday,
      currentStreak,
      weeklyCompletion
    };
  }
}

// Create and export the storage instance
export const storage = new MemStorage();
