import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { format } from "date-fns";
import { insertHabitSchema, insertHabitCompletionSchema } from "@shared/schema";
import { ZodError } from "zod";
import archiver from "archiver";
import path from "path";

export async function registerRoutes(app: Express): Promise<Server> {
  // Create the HTTP server
  const httpServer = createServer(app);

  // Get all habits
  app.get("/api/habits", async (_req, res) => {
    try {
      const habits = await storage.getHabits();
      res.json(habits);
    } catch (error) {
      console.error("Error fetching habits:", error);
      res.status(500).json({ message: "Failed to fetch habits" });
    }
  });

  // Get habits scheduled for a specific day
  app.get("/api/habits/day/:day", async (req, res) => {
    try {
      const day = req.params.day;
      const habits = await storage.getHabitsByDay(day);
      res.json(habits);
    } catch (error) {
      console.error(`Error fetching habits for day ${req.params.day}:`, error);
      res.status(500).json({ message: "Failed to fetch habits for the specified day" });
    }
  });

  // Get preset habits
  app.get("/api/habits/presets", async (_req, res) => {
    try {
      const presets = await storage.getPresetHabits();
      res.json(presets);
    } catch (error) {
      console.error("Error fetching preset habits:", error);
      res.status(500).json({ message: "Failed to fetch preset habits" });
    }
  });

  // Get a specific habit
  app.get("/api/habits/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid habit ID" });
      }

      const habit = await storage.getHabit(id);
      if (!habit) {
        return res.status(404).json({ message: "Habit not found" });
      }

      res.json(habit);
    } catch (error) {
      console.error(`Error fetching habit ${req.params.id}:`, error);
      res.status(500).json({ message: "Failed to fetch habit" });
    }
  });

  // Create a new habit
  app.post("/api/habits", async (req, res) => {
    try {
      // Validate request body
      const habitData = insertHabitSchema.parse(req.body);
      const habit = await storage.createHabit(habitData);
      res.status(201).json(habit);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Invalid habit data", 
          errors: error.errors 
        });
      }
      console.error("Error creating habit:", error);
      res.status(500).json({ message: "Failed to create habit" });
    }
  });

  // Update a habit
  app.patch("/api/habits/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid habit ID" });
      }

      // Validate request body (partial schema)
      const updates = insertHabitSchema.partial().parse(req.body);
      const updatedHabit = await storage.updateHabit(id, updates);

      if (!updatedHabit) {
        return res.status(404).json({ message: "Habit not found" });
      }

      res.json(updatedHabit);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Invalid habit data", 
          errors: error.errors 
        });
      }
      console.error(`Error updating habit ${req.params.id}:`, error);
      res.status(500).json({ message: "Failed to update habit" });
    }
  });

  // Delete a habit
  app.delete("/api/habits/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid habit ID" });
      }

      const success = await storage.deleteHabit(id);
      if (!success) {
        return res.status(404).json({ message: "Habit not found" });
      }

      res.status(204).end();
    } catch (error) {
      console.error(`Error deleting habit ${req.params.id}:`, error);
      res.status(500).json({ message: "Failed to delete habit" });
    }
  });

  // Get habits with today's completion status
  app.get("/api/habits/with-completion/today", async (_req, res) => {
    try {
      const habitsWithCompletion = await storage.getHabitsWithTodayCompletion();
      res.json(habitsWithCompletion);
    } catch (error) {
      console.error("Error fetching habits with completion status:", error);
      res.status(500).json({ message: "Failed to fetch habits with completion status" });
    }
  });

  // Mark a habit as completed or uncompleted
  app.post("/api/habits/:id/complete", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid habit ID" });
      }

      const { completed } = req.body;
      if (typeof completed !== 'boolean') {
        return res.status(400).json({ message: "Completed status must be a boolean" });
      }

      const completion = await storage.markHabitAsCompleted(id, completed);
      res.json(completion);
    } catch (error) {
      console.error(`Error completing habit ${req.params.id}:`, error);
      res.status(500).json({ message: "Failed to update habit completion status" });
    }
  });

  // Get habit completion history
  app.get("/api/habits/:id/completions", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid habit ID" });
      }

      const days = req.query.days ? parseInt(req.query.days as string) : 30;
      const completions = await storage.getHabitCompletions(id, days);
      res.json(completions);
    } catch (error) {
      console.error(`Error fetching completions for habit ${req.params.id}:`, error);
      res.status(500).json({ message: "Failed to fetch habit completions" });
    }
  });

  // Get habit statistics
  app.get("/api/stats", async (_req, res) => {
    try {
      const stats = await storage.getHabitStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching habit statistics:", error);
      res.status(500).json({ message: "Failed to fetch habit statistics" });
    }
  });

  app.use(express.json());

  // Download project endpoint
  app.get('/api/download', (req, res) => {
    const archive = archiver('zip', {
      zlib: { level: 9 }
    });

    res.attachment('habit-tracker.zip');
    archive.pipe(res);

    // Add directories
    archive.directory('client/', 'client');
    archive.directory('server/', 'server');
    archive.directory('shared/', 'shared');

    // Add config files
    archive.file('package.json', { name: 'package.json' });
    archive.file('tsconfig.json', { name: 'tsconfig.json' });
    archive.file('theme.json', { name: 'theme.json' });
    archive.file('tailwind.config.ts', { name: 'tailwind.config.ts' });

    archive.finalize();
  });

  return httpServer;
}