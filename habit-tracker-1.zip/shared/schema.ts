import { pgTable, text, serial, integer, boolean, date, time, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Define days of the week for habit repetition
export const DaysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'] as const;
export type DayOfWeek = typeof DaysOfWeek[number];

// Predefined categories for habits
export const Categories = ['Sport', 'Health', 'Wellness', 'Personal', 'Work', 'Education'] as const;
export type Category = typeof Categories[number];

// Define the habits table
export const habits = pgTable("habits", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category").$type<Category>().notNull(),
  createdAt: date("created_at").notNull().defaultNow(),
  isActive: boolean("is_active").notNull().default(true),
  // Store days of week for habit repetition (e.g., ['Monday', 'Wednesday', 'Friday'])
  repeatDays: jsonb("repeat_days").$type<DayOfWeek[]>().notNull(),
  // Store reminder times as string array (e.g., ["08:00", "19:30"])
  reminderTimes: jsonb("reminder_times").$type<string[]>().default([]),
  // For preset habits, this will be true
  isPreset: boolean("is_preset").notNull().default(false),
  // Icon for the habit (especially for presets)
  icon: text("icon").default("star"),
});

// Define the habit completions table to track daily completions
export const habitCompletions = pgTable("habit_completions", {
  id: serial("id").primaryKey(),
  habitId: integer("habit_id").notNull().references(() => habits.id),
  completedDate: date("completed_date").notNull().defaultNow(),
  completed: boolean("completed").notNull().default(false),
});

// Create Zod schemas for validation
export const insertHabitSchema = createInsertSchema(habits).omit({
  id: true,
  createdAt: true,
});

export const insertHabitCompletionSchema = createInsertSchema(habitCompletions).omit({
  id: true,
});

// Define types for habit and completion
export type Habit = typeof habits.$inferSelect;
export type InsertHabit = z.infer<typeof insertHabitSchema>;
export type HabitCompletion = typeof habitCompletions.$inferSelect;
export type InsertHabitCompletion = z.infer<typeof insertHabitCompletionSchema>;

// Extended habit type that includes completion status for a specific day
export type HabitWithCompletion = Habit & {
  isCompletedToday: boolean;
};

// Stats type for habit tracking
export type HabitStats = {
  totalHabits: number;
  completedToday: number;
  currentStreak: number;
  weeklyCompletion: number; // percentage
};
